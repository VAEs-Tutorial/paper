'''
Created on Jul 5, 2020

@author: Ahmed-ElSayed
'''
import os 
import cv2
import numpy as np

y_value = []
x_value = []
for root, dirs, files in os.walk('./images'):
    for name in dirs:
        for root2, dirs2, files2 in os.walk('./images/'+name):
            for image_name in files2:
                x_value.append(cv2.imread('./images/'+name+'/'+image_name,0))
                y_value.append(int(name))
                
x_value = np.array(x_value)
y_value = np.array(y_value)

import matplotlib.pyplot as plt
 
import tensorflow as tf

x_value = x_value.astype('float32')
x_value /= 255
x_value = x_value.reshape(x_value.shape[0], 28, 28, 1)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, Dropout, Flatten, MaxPooling2D
input_shape = (28, 28, 1)
# Creating a Sequential Model and adding the layers
model = Sequential()
model.add(Conv2D(16, kernel_size=(3,3), input_shape=input_shape,activation=tf.nn.relu))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Conv2D(32, kernel_size=(3,3),activation=tf.nn.relu))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Conv2D(64, kernel_size=(3,3),activation=tf.nn.relu))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Flatten()) # Flattening the 2D arrays for fully connected layers
model.add(Dense(20, activation=tf.nn.relu))
model.add(Dropout(0.2))
model.add(Dense(10,activation=tf.nn.softmax))
 
model.load_weights('MNIST_classifier_VAE.h5')

predict = model.predict(x_value)

output = predict.argmax(1)

correct = output==y_value

accuracy = np.sum(correct)/correct.shape[0]

print('The accuracy of the generated images  = '+str(accuracy*100)+' %')

